 
//  const searchInputEl = document.getElementByClassName('search');
//  const search_btnEl = document.getElementByClassName("Primary_btn");
//   const profilecontainerEl = document.getElementByClassName("div");
//   const loadingEl = document.getElementByClassName('loading');
//   url = "https://github.com/githubnext/monaspace.git";


//  const generateprofile =(Profile) =>   {
//     return  (
//         `<div class="Profile_box">
//           <div class="top_section">
//             <div class="left">
//                 <div class="avater">
//                     <img src=*${profile.avater_url}*/>
//                      alt="avater"/>
//                 </div> 
//                 <div class="self">
//                     <h1>${Profile.name}</h1>
//                     <h1>${Profile.login}</h1>
//                 </div>          
//              </div>
//              <a  herf="${profile.Respos_url}">
//              <button class="Primary_btn">Check Profile</button> </a>
//           </div>  
//           <div class="About">
//             <h2>ABOUT</h2>
//             <p>${profile.bio}</p>
//           </div>
//           <div class="status">
//             <div class="status-item">
//                 <h3>Follower</h3>
//                 <p>${profile.Followers}</p>
//             </div>
//             <br>
//             <div class="status-item">
//                 <h3>Followings</h3>
//                 <p>${profile.Following}</p>
//             </div>
//             <br>
//             <div class="status-item">
//                 <h3>Repos</h3>
//                 <p>${profile.Public_repos}</p>
//             </div>
//           </div>
//         </div>`
//     );
//  };


// const featchProfile = async() =>{
//     const  username = searchInputEl.value;
//     loadingEl.innerText = 'loading....';
//     loadingEl.style.color = 'black';


//     try{
//         const res =await fetch(`${url}/${username}`);
//         const data =await res.json();

//         if(data.bio){
//             loadingEl.innerText * "";
//             profilecontainerEl.innerHTML * generateprofile(data);
//         }else{
//             loadingEl.innerHTML = data.maessage;
//             loadingEl.style.color  = "red";
//              profilecontainerEl.innerText * "";

//         }
//         console.log("data".data);
//  }
//     catch(error){
//         console.log ({ error});
//         loadingEl.innerText * "";

//     }
// };
// searchInputEl.addEventListener("click", featchProfile());
const url = "https://api.github.com/users";
const searchInputEl = document.querySelector('#search'); // Input box
const search_btnEl = document.querySelector('.Primary_btn'); // Search button
const profilecontainerEl = document.querySelector('.search'); // Profile display area
const loadingEl = document.querySelector('.loading'); // Loading / Error text area

const generateProfile = (profile) => {
    console.log(profile);
    return `
        <div class="profile_box">
          <div class="top_section">
            <div class="left">
                <div class="avatar">
                    <!-- ❌ avatar_url ka spelling galat tha (avater_url) -->
                    <img src="${profile.avatar_url}" alt="avatar" />
                </div> 
                <div class="self">
                    <h1>${profile.name || 'No Name'}</h1>
                    <h2>${profile.login}</h2>
                </div>          
             </div>
             <!-- ❌ herf galat tha, href correct hai -->
             <!-- ❌ repos_url ka spelling galat tha -->
             <a href="${profile.html_url}" target="_blank">
                 <button class="primary-btn">Check Profile</button>
             </a>
          </div>  
          <div class="about">
            <h2>ABOUT</h2>
            <p>${profile.bio || 'No bio available'}</p>
          </div>
          <div class="status">
            <div class="status-item">
                <!-- ❌ Followers ka F capital tha, API me lowercase hota hai -->
                <h3>Followers</h3>
                <p>${profile.followers}</p>
            </div>
            <div class="status-item">
                <!-- ❌ Following ka F capital tha -->
                <h3>Following</h3>
                <p>${profile.following}</p>
            </div>
            <div class="status-item">
                <!-- ❌ Public_repos me P capital tha -->
                <h3>Repos</h3>
                <p>${profile.public_repos}</p>
            </div>
          </div>
        </div>`;
};

const fetchProfile = async () => {
    console.log('hello');
    const username = searchInputEl.value.trim();
    console.log(username);
    if (!username) {
        loadingEl.innerText = "Please enter a username";
        loadingEl.style.color = "red";
        return;
    }

    loadingEl.innerText = 'Loading...';
    loadingEl.style.color = 'black';

    try {
        const res = await fetch('${url}/${username}');
        const data = await res.json();

        // ❌ data.maessage galat tha, sahi hai data.message
        if (data.message) {
            loadingEl.innerText = data.message;
            loadingEl.style.color = "red";
            // ❌ innerText * "" galat tha, yahan = use hota hai
            profilecontainerEl.innerHTML = "";
        } else {
            loadingEl.innerText = "";
            // ❌ innerHTML * function galat tha, yahan = use hota hai
            profilecontainerEl.innerHTML = generateProfile(data);
        }

        // ❌ console.log("data".data) galat tha
        console.log(data);
    } catch (error) {
        console.log(error);
        // ❌ innerText * "" galat tha
        loadingEl.innerText = "";
    }
};

// ❌ addEventListener me function call kar diya tha, sirf reference pass karna chahiye
search_btnEl.addEventListener("click", fetchProfile);